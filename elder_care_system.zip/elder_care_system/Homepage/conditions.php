<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="term1.css">
<title> Elder Care Management System</title>
</head>
<body>

<div class="header">
  <h>Elder Care Management System</h>
</div>
<div id="top">
         <button onclick="location.href='../Admin/loginform.php'">Admin</button>
</div>  
<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../Admin/homelist.php">Vacancy Check</a>
  <a href="../ContactUs/contact.php">Contact Us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>

<div class="content">
        <h1>Terms and Conditions<br><br></h1>

<b>Use of this site is provided by website subject to the following Terms and Conditions:</b><br></b><br>

    Your use constitutes acceptance of these terms and conditions as at the date of your first use of the site.<br><br>
    This website reserves the rights to change these terms and conditions at any time by posting changes online. Your continued use of this site after changes are posted constitutes your acceptance of this agreement as modified.<br><br>
    You agree to use this site only for lawful purposes, and in a manner which does not infringe the rights, or restrict, or inhibit the use and enjoyment of the site by any third party.<br><br>    This site and the information, names, images, pictures, logos regarding or relating to This website is provided “as is” without any representation or endorsement made and without warranty of any kind whether express or implied. In no event will website be liable for any damages including, without limitation, indirect or consequential damages, or any damages whatsoever arising from the use or in connection with such use or loss of use of the site, whether in contract or in negligence.<br><br>
    This website does not warrant that the functions contained in the material contained in this site will be uninterrupted or error free, that defects will be corrected, or that this site or the server that makes it available are free of viruses or bugs or represents the full functionality, accuracy and reliability of the materials.<br>
    </p>
</body>

</div>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>
</body>
</html>

