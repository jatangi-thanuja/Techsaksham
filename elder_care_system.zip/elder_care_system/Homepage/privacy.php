<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="privacy.css">
<title> Elder Care Management System</title>
</head>
<body>

<div class="header">
  <p>Elder Care Management System</p>
</div>
<div id="top">
         <button onclick="location.href='loginform.php'">Admin</button>
</div>  
<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../Admin/homelist.php">Vacancy Check</a>
  <a href="../ContactUs/contact.php">Contact Us</a>
  <a href="../Volunteer/voluntter.php">Volunteer</a>
  <a href="../Donation/donate.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>

<div class="content">
<h1>Our Commitment</h1>
    <p>This includes protecting your privacy. Any information you provide to us remains private and is only used for the purposes outlined below. We don’t rent, sell or exchange our contact lists.</p>
    <div class="p1">
        <h1>The personal information we typically ask you for is:</h1>

        <p>Contact details (name, address, e-mail, phone numbers)
    We will ensure your personal information is held securely, in accordance with the Data Protection Act.</p>
    </div>
    <div class="p2">
         <h1>payment process:</h1>
            <p>By proceeding with the transaction Donor understands that the transaction is final and once the payment is made, then the donor not eligible for any claims. Further, donor confirms that all personal details provided in this form are true and correct. Donor further agree to indemnify This website against any and all claims, losses and damages that may arise out of false or incorrect information submitted by the donor.
            
            We would like to let you know how your donation has been put hard to work changing lives. We promise not to spam you, pass on your details to someone else or constantly pester you for more money.</p>
    </div>
</div>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>

</body>
</html>