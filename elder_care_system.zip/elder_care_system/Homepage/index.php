<?php
 session_start();
?>
 <!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>  Elder Care Management System</title>
	<link rel="stylesheet" type="text/css" href="style.css"> 
	<link rel="stylesheet" type="text/css" href="home.css">	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>
</head>
<body>
	<div class="top">
   <div>
     <img src="weblogo.png" height="160" width="160" class="logo" >
   </div>
   <div class="title"> Elder Care Managemant System</div>
   <div id="admin">
   <button class="ad" onclick="location.href='../Admin/loginform.php'">Admin</button>
   </div>
</div>
<div id="nav">
<nav>
<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="../vacancyCheck/homelist.php">Vacancy Check</a></li>
  <li><a href="../ContactUs/contact.php">Contact Us</a></li>
  <li><a href="../Donation/donation.php">Donation</a></li>
  <li><a href="../Volunteer/volunteer.php">Volunteer</a></li>
  <li><a href="../Media/media.php">Media</a></li>
  <li style="float:right"><a class="active" href="../AboutUs/aboutus.php">About Us</a></li>
</ul>
</nav>
</div>
	<div class="slides slowFade">
        <div class="slide">
            <img src="1.jpg" alt="img"/>
        </div>
        <div class="slide">
            <img src="2.jpg" alt="img"/>
        </div>
        <div class="slide">
            <img src="3.jpg" alt="img"/>
        </div>
        <div class="slide">
            <img src="4.jpeg" alt="img"/>
        </div>
        <div class="slide">
            <img src="5.jpg" alt="img"/>
        </div>
    </div>
<footer>
   <h1 style="font-size:21px;">Elder Care Management System </h1>
   <p>Elder Care Managent System is a website <br/>which handles information about aged and homeless people.<br/>This website gives   information        about vacancies in  rayalaseema districts.</p>
  <div class="socialmedia">
      <a href="#" class="fa fa-facebook"></a>
      <a herf="#" class="fa fa-instagram"></a>
      <a herf="#" class="fa fa-linkedin"></a>
      <a href="#" class="fa fa-twitter"></a>
  </div>
  <div class="links">
     <button class="button button1" onclick="location.href='index.php'">Home</button>&nbsp
     <button class="button button2" onclick="location.href='../AboutUs/aboutus.php'">About</button>&nbsp
     <button class="button button3" onclick="location.href='../ContactUs/contact.php'">Contact</button>&nbsp
     <button class="button button4" onclick="location.href='../Donation/donation.php'">Donate</button>&nbsp
     <button class="button button5" onclick="location.href='../vacancyCheck/homelist.php'">Vacancy Check</button>
  </div>
  <div class="end">
     <p>
    © Copyright 2023 Elder Care Managemant System. All rights reserved &nbsp&nbsp&nbsp&nbsp &nbsp &nbsp &nbsp<a href="privacy.php" style="color:black">privacy policy</a> &nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp <a href="conditions.php" style="color:black">Terms and Conditions</a> &nbsp&nbsp &nbsp &nbsp Disclaimer </p>
  </div>
</footer>
</body>
</html