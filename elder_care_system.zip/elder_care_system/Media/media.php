<?php
  include("navbar.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="media.css">
      <title> Elder Care Management System</title>
</head>
<body>

<h2 style="text-align:center"></h2>

<div class="row">
	<div class="column">
    		<img src="n.jpg" style="width:100%;height:100%" onclick="openModal();currentSlide(1)" class="hover-shadow cursor">
  	</div>
  	<div class="column">
    		<img src="n1.jpg" style="width:100%" onclick="openModal();currentSlide(2)" class="hover-shadow cursor">
 	</div>
  	<div class="column">
    		<img src="n2.jpg" style="width:100%" onclick="openModal();currentSlide(3)" class="hover-shadow cursor">
  	</div>
  	<div class="column">
    		<img src="n3.jpg" style="width:100%" onclick="openModal();currentSlide(4)" class="hover-shadow cursor">
  	</div>
	<div class="column">
    		<img src="m.jpg" style="width:100%" onclick="openModal();currentSlide(5)" class="hover-shadow cursor">
  	</div>
	 <div class="column">
    		<img src="m1.jpg" style="width:100%" onclick="openModal();currentSlide(6)" class="hover-shadow cursor">
  	</div>
  	<div class="column">
    		<img src="m2.jpg" style="width:100%" onclick="openModal();currentSlide(7)" class="hover-shadow cursor">
 	 </div>
  	<div class="column">
    		<img src="m3.jpg" style="width:100%" onclick="openModal();currentSlide(8)" class="hover-shadow cursor">
  	</div>
  	<div class="column">
    		<img src="m4.jpg" style="width:100%" onclick="openModal();currentSlide(9)" class="hover-shadow cursor">
  	</div>
	<div class="column">
   		 <img src="m5.jpg" style="width:100%" onclick="openModal();currentSlide(10)" class="hover-shadow cursor">
  	</div>
	<div class="column">
    		<img src="m6.jpg" style="width:100%" onclick="openModal();currentSlide(11)" class="hover-shadow cursor">
  	</div>
	<div class="column">
    		<img src="m7.jpg" style="width:100%" onclick="openModal();currentSlide(12)" class="hover-shadow cursor">
  	</div>
	<div class="column">
    		<img src="m8.jpg" style="width:100%" onclick="openModal();currentSlide(13)" class="hover-shadow cursor">
  	</div>
	<div class="column">
   		 <img src="m9.png" style="width:100%" onclick="openModal();currentSlide(14)" class="hover-shadow cursor">
  	</div>
	<div class="column">
    		<img src="nb.jpg" style="width:100%" onclick="openModal();currentSlide(15)" class="hover-shadow cursor">
  	</div>
	<div class="column">
    		<img src="nb1.jpg" style="width:100%" onclick="openModal();currentSlide(16)" class="hover-shadow cursor">
  	</div>
</div>

<div id="myModal" class="modal">
  <span class="close cursor" onclick="closeModal()">&times;</span>
  <div class="modal-content">

    <div class="mySlides">
      <div class="numbertext">1 / 4</div>
      <img src="n.jpg" style="width:100%;height:100%">
    </div>

    <div class="mySlides">
      <div class="numbertext">2 / 4</div>
      <img src="n1.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">3 / 4</div>
      <img src="n2.jpg" style="width:100%;height:100%">
</div>
 <div class="mySlides">
      <div class="numbertext">4 / 4</div>
      <img src="n3.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">5 / 4</div>
      <img src="m.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">6 / 4</div>
      <img src="m1.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">7 / 4</div>
      <img src="m2.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">8/ 4</div>
      <img src="m3.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">9 / 4</div>
      <img src="m4.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">10 / 4</div>
      <img src="m5.jpg" style="width:100%;height:100%">
  </div>
<div class="mySlides">
      <div class="numbertext">11 / 4</div>
      <img src="m6.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">12 / 4</div>
      <img src="m7.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">13 / 4</div>
      <img src="m8.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">14 / 4</div>
      <img src="m9.png" style="width:100%;height:100%">
  </div>
<div class="mySlides">
      <div class="numbertext">15 / 4</div>
      <img src="nb.jpg" style="width:100%;height:100%">
</div>
<div class="mySlides">
      <div class="numbertext">16 / 4</div>
      <img src="nb1.jpg" style="width:100%;height:100%">
</div>
<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>
<div class="caption-container">
      <p id="caption"></p>
</div>
 <div class="column">
      <img class="demo cursor" src="n.jpg" style="width:100%" onclick="currentSlide(1)" alt="Nature and sunrise">
</div>
<div class="column">
      <img class="demo cursor" src="n1.jpg" style="width:100%" onclick="currentSlide(2)" alt="Snow"
</div>
<div class="column">
      <img class="demo cursor" src="n2.jpg" style="width:100%" onclick="currentSlide(3)" alt="Mountains and fjords">
</div>
<div class="column">
      <img class="demo cursor" src="n3.jpg" style="width:100%" onclick="currentSlide(4)" alt="Northern Lights">
</div>
<div class="column">
      <img class="demo cursor" src="m.jpg" style="width:100%" onclick="currentSlide(5)" alt="Northern Lights">
</div>
<div class="column">
      <img class="demo cursor" src="m1.jpg" style="width:100%" onclick="currentSlide(6)" alt="Nature and sunrise">
</div>
<div class="column">
      <img class="demo cursor" src="m2.jpg" style="width:100%" onclick="currentSlide(7)" alt="Snow"
</div>
<div class="column">
      <img class="demo cursor" src="m3.jpg" style="width:100%" onclick="currentSlide(8)" alt="Mountains and fjords">
</div>
<div class="column">
      <img class="demo cursor" src="m4.jpg" style="width:100%" onclick="currentSlide(9)" alt="Northern Lights">
</div>
<div class="column">
      <img class="demo cursor" src="m5.jpg" style="width:100%" onclick="currentSlide(10)" alt="Northern Lights">
</div>
<div class="column">
      <img class="demo cursor" src="m6.jpg" style="width:100%" onclick="currentSlide(11)" alt="Northern Lights">
</div>
<div class="column">
      <img class="demo cursor" src="m7.jpg" style="width:100%" onclick="currentSlide(12)" alt="Northern Lights">
</div>
<div class="column">
      <img class="demo cursor" src="m8.jpg" style="width:100%" onclick="currentSlide(13)" alt="Northern Lights">
</div>
<div class="column">
      <img class="demo cursor" src="m9.png" style="width:100%" onclick="currentSlide(14)" alt="Northern Lights">
</div>
<div class="column">
      <img class="demo cursor" src="nb.jpg" style="width:100%" onclick="currentSlide(15)" alt="Northern Lights">
</div>
<div class="column">
      <img class="demo cursor" src="nb1.jpg" style="width:100%" onclick="currentSlide(16)" alt="Northern Lights">
</div>
<script>
function openModal() {
  document.getElementById("myModal").style.display = "block";
}

function closeModal() {
  document.getElementById("myModal").style.display = "none";
}

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>
    
</body>
</html>

