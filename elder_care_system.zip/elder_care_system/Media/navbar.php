<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="navbar.css">
</head>
<body>
<div class="header">
  <p>Elder Care Management System</p>
</div>
<div id="top">
         <button onclick="location.href='../Admin/loginform.php'">Admin</button>
</div>

<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../vacancyCheck/homelist.php">Vacancy Check</a>
  <a href="../ContactUs/contact.php">Contact us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media<a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>

<div class="content">
</div>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>
</body>
</html>