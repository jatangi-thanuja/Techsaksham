<?php
session_start();
include("../includes/config.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width initial-scae=1.0">
	<link rel="stylesheet" href="aboutus.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title> Elder Care Management System</title>
</head>
<body>
<div id="header">
  <p>Elder Care Management System</p>
</div>
<div id="top">
         <button onclick="location.href='../Admin/loginform.php'">Admin</button>
</div>
<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../vacancyCheck/homelist.php">Vacancy check</a>
  <a href="../ContactUs/contact.php">Contact Us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>
<div class="content">
<div class="image">
	<video width="675" height="405" controls muted loop autoplay>
		<source src="animate.mp4" type="video/mp4">
    </video>
</div>
<div class="blink" id="a">
	<p><i><b><u>OUR VISION</u></b></p><br>
	<p><li>proividing living facilities for needy people.</li><br>
  <li>providing happy retirement.</li><br>
  <li>unlimited happiness.</li><br>
   <li>family members.</li></p>
</div>
<div class="b">
	<img src="m1.jpg">
</div>
<div class="blink" id="c" >
	<p><b>OUR MISSION</b></p>
	<p><i><li>spread smiles.</li><br>
	<li>give support.</li><br>
	<li>provide new family members.</li><br>
	<li>To give happiness.</li><br>
	<li>provide good health.
	</li></p>
</div>
</div>
<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>
</body>
</html>