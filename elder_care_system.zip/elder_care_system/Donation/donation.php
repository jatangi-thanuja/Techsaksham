<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="donate.css">
<title> Elder Care Management System</title>
</head>
<body>
<div class="header">
  <p>Elder Care Management System</p>
</div>
<div id="top">
         <button onclick="location.href='loginform.php'">Admin</button>
</div>

<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../vacancyCheck/homelist.php">Vacancy check</a>
  <a href="../ContactUs/contact.php">Contact us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>
<div class="content">
  
<h1> Donate Now</h1>  
<form method="post" action="">
         <div class="data">
      <div id="form1">
      <label>Enter Name:</label><br>
			<input type="text" class="size" name="name" value=""  id="name" placeholder="enter name" required><br>
	 		<label for="id2">Select Gender:</label><br>
		    <select id="id2" name="gender" class="size">
				<option value="" >select</option>
			  <option value="Male">Male</option>
			  <option value="Female">Female</option>
				<option value="Others">Others</option>
			</select><br>
      <label>Phone Nmber:</label><br>
			<input type="text" placeholder="enter number" name="phone" value="" class="size" id="number" required><br/>
      <label> Email :</label><br>
      <input type="email"  placeholder="Email" name="email" class="size" value="" id="email" required><br>
	 		<label>Address :</label><br>
      <textarea style="width:250px; height:20px" name="address"></textarea><br>
    </div>
    <div id="form2">
      <label>Enter Amount:</label><br>
			<input type="number" class="size" placeholder="enter amount" name="amount"  id="amount" min="1" max="1000000" required/><br>
			<label for="id1">Select project:</label><br>
			<select id="id1" name="project" class="size">
				<option value="">select</option>
				<option value="Clothes">Clothes</option>
				<option value="Festive Celebrations">Festive Celebrations</option>
				<option value="Food">Food</option>
				<option value="Helath Camps">Health Camps</option>
				<option value="Medical Support">Medical Support</option>
				<option value="One Time Donation">One Time Donation</option>
			</select><br><br>
	    <input type="submit" name="submit" value="Donate Now" id="rzp-button1">	
  </div>
</form>
</div>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
   var name = document.getElementById("name").value;
   var mobile = document.getElementById("number").value;
   var email = document.getElementById("email").value;  
   var amount = document.getElementById("amount").value;
var options = {
    "key": "rzp_test_FN3IFn2zwZA6Ic", // Enter the Key ID generated from the Dashboard
    "amount": "50000", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "Elder Care Management ", //your business name
    "description": "Test Transaction",
    "image": "https://example.com/your_logo",
    //"order_id": orderID, //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
    "callback_url": "donation.php",
    "prefill": {
        "name": name, //your customer's name
        "email": email,
        "contact":mobile
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#3399cc"
    }
};
var rzp1 = new Razorpay(options);
rzp1.on('payment.failed',function(response)
{
  alert(response.error.code);
  alert(response.error.description);
  alert(response.eror.source);
  alert(alert.error.step);
  alert(response.error.reason);
  alert(response.error.metadata.order_id);
  alert(response_error.metadata.payment_id);
})
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
  }
</script>
<script>
window.onscroll = function() {myFunction()};
var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>
</body>
</html>
