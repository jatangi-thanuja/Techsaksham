<?php
session_start();
include("../includes/config.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="homelist.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>
<title> Elder Care Management System</title>
</head>
<body>

<div class="header">
  <p>Elder Care Management System</p>
</div>
<div id="top">
     <button onclick="location.href='../Admin/loginform.php'">Admin</button>
  </div>

<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../vacancyCheck/homelist.php">Vacancy Check</a>
  <a href="../ContactUs/contact.php">Contact Us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>

<div class="content">
<div id="buttons">
    <button  name="Atp"  id="atpr">Anantapur</button><br>
    <button  name="Ctr" id="chtr">Chittor</button><br>
    <button  name="gnt" id="gnr">Guntur</button><br>
    <button  name="Kdp" id="kdpa">Kadapa</button><br>
    <button name="kak" id="kand">Kakinada</button><br>
    <button  name="Krnl" id="krnl">Kurnool</button><br>
    <button  name="Nlr" id="nllr">Nellore</button><br>
    <button name="ong" id="ongl">Ongloe</button><br>
    <button name="vij" id="vija">Vijayawada</button><br>
    <button name="viz" id="viza">Vizag</button><br>
  </form>
</div>
<div id="loading">
</div>
</div>
<marquee direction="right">
<img src="four.jpg" width="150px" height="130px"/>
</marquee>
<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>
<script>
     $(document).ready(function(){
           $("#atpr").click(function(){
                $("#loading").load("home.php");
           });
           $("#chtr").click(function(){
                $("#loading").load("chittor.php");
           });
           $("#kdpa").click(function(){
                $("#loading").load("kadapa.php");
           });
           $("#krnl").click(function(){
                $("#loading").load("Anantapur.php");
           });
           $("#nllr").click(function(){
                $("#loading").load("nellore.php");
           });
           $("#gnr").click(function(){
                $("#loading").load("guntur.php");
           });
           $("#kand").click(function(){
                $("#loading").load("kakinada.php");
           });
           $("#ongl").click(function(){
                $("#loading").load("ongole.php");
           });
           $("#viza").click(function(){
                $("#loading").load("vizag.php");
           });
           $("#vija").click(function(){
                $("#loading").load("vijayawada.php");
           });
     });
</script>
</div>
</body>
</html>