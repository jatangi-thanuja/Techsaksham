<?php
session_start();
include("../includes/config.php");
$query= "select *  from homelist where AdminId like 'GN%' ";
$result=$con->query($query);
?>
<table border="1" cellspacing="0" cellpadding="10">
<tr>
    <th>S.NO</th>
    <th>HomeName</th>
    <th>Address</th>
    <th>Phone Number</th>
    <th>Rating</th>
    <th>AdminId</th>
</tr>
<?php
if($result->num_rows>0)
{
    $sn=1;
    while($data=$result->fetch_assoc())
    {?> 
<tr>
    <td><?php echo $sn;?></td>
    <td><?php echo $data['HomeName'];?></td>
    <td><?php echo $data['Address'];?></td>
    <td><?php echo $data['PhoneNumber'];?></td>
    <td><?php echo $data['Rating'];?></td>
    <td><?php echo $data['AdminId'];?></td>
</tr>
<?php 
$sn++;}}
else{?>
<tr> 
    <td colspan="8">No data found</td>
</tr>
<?php }?>
</table>