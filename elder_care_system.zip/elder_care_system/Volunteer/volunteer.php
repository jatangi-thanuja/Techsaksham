<?php
     session_start();
     include("../includes/config.php"); 
	  if(isset($_POST['submit']))
	   {
            $name=$_POST["name"];
			$phone_number=$_POST["phone"];
			$age=$_POST["age"];
			$email=$_POST["email"];
			$role=$_POST["role"];
			$duration=$_POST["duration"];
			$gender=$_POST["gender"];
			if(!preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/', trim($_POST["email"])))
			{
			
				echo "<script type='text/javascript'>
				alert('Please enter correct email address');
				location='volunteer.php';
				</script>";
            }
	      	if(!empty($_FILES["image"]["name"]))
         	{
       			 $filename=basename($_FILES["image"]["name"]);
        		 $filetype=pathinfo($filename,PATHINFO_EXTENSION);
                $allowTypes=array('jpg','png','jpeg','gif');
                if(in_array($filetype,$allowTypes))
                  {
                     $image=$_FILES['image']['tmp_name'];
                     $imgcontent=addslashes(file_get_contents($image));
                     $insert= $con->query("insert into volunteer(Name,phone_number,Age,Gender,Email,Role,Days,image,created) values('$name','$phone_number','$age','$gender','$email','$role','$duration','$imgcontent',NOW())");
                     if($insert)
                      {
                          echo "<script type='text/javascript'>
                           alert('Thank you for being part of us');
                            location='volunteer.php';
                            </script>";
                      }
                    else
                     {
                         echo "<script type='text/javascript'>
                        alert('fileupload falied ');
                         location='voluntter.php';
                         </script>";
                      }
                  }
                else
                 {
                     echo "<script type='text/javascript'>
                     alert('image should be in jpg,jpeg,png,gfg and it shoulb be less than 1 mb ');
                     location='volunteer.php';
                     </script>";
                 }
            }
          else
            {
                echo "<script type='text/javascript'>
                   alert('please upload an image');
                   location='volunteer.php';
                    </script>";
             }
       }
		    
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="volunteer.css">
<title> Elder Care Management System</title>
</head>
<body>
<div id="top">
         <button onclick="location.href='../Admin/loginform.php'">Admin</button>
</div>
<div class="header">
  <p>Elder Care Management System</p>
</div>
<div id="top">
         <button onclick="location.href='../Admin/loginform.php'">Admin</button>
</div>
<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../vacancyCheck/homelist.php">Vacancy Check</a>
  <a href="../ContctUs/contact.php">Contact Us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>

<div class="content">
<p><i>LET'S JOIN AS VOLUNTEER</i></p>
<div id="media">
<img src="volunteer.jpg">
<video width="500" height="400" controls muted loop autoplay>
		<source src="volunteer.mp4" type="video/mp4">
</video>
</div>
<div class="back">
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
			<p id="line">FILL YOUR DETAILS</p>
			<div class="data">
				<div class="a">
					<label>Name:</label><br>
					<input type="text" class="size" name="name" required/><br>
					<label>Phone Number:</label><br>
					<input type="text" class="size" name="phone" required/><br>
					<label>Age:</label><br>
					<input type="number" class="size" name="age" required><br>
					<label>Gender:</label><br>
					<select id="" class="size" name="gender" required><br>
						<option value="">select</option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
						<option value="others">Others</option>
					</select><br>
					<label>Mail:</label><br>
					<input type="mail" class="size" name="email" required/>
				</div>
				<div class="b">
					<label>what would you like to do as:</label><br>
					<select id="" class="size" name="role" required><br>
						<option value="">select</option>
						<option value="Volunteer">volunteer</option>
						<option value="Full Time">Full Time</option>
					</select><br>
					<label>How Many Days Could You<br>Able To Work:</label><br>
					<input type="text" class="size" name="duration" required><br>
					<label>Select Image File:</label><br>
                    <input type="file" name="image"><br><br>
				</div>
			</div>
		<div class="submit">
				<input type="submit" name="submit" value="submit">
		</div>
		</div>
	</form>
</div>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>

</body>
</html>