<?php
session_start();
include("../includes/config.php");
$query="select Name,phone_number,Age,Gender,Email,Role,Days,image,created from volunteer";
$result=$con->query($query);
?>
<table border="1" cellspacing="0" cellpadding="10">
<tr>
<th>S.NO</th>
    <th>Name</th>
    <th>Gender</th>
    <th>Age</th>
    <td>Phone_Number</th>
    <th>Email</th>
    <th>Role</th>
    <th>Days_Of_Work</th>
    <th>Photo</th>
    <th>Joined Date</th>
</tr>
<?php
if($result->num_rows>0)
{
    $sn=1;
    while($data=$result->fetch_assoc())
    {?> 
<tr>
    <td><?php echo $sn;?></td>
    <td><?php echo $data['Name'];?></td>
    <td><?php echo $data['Gender'];?></td>
    <td><?php echo $data["Age"] ?></td>
    <td><?php echo $data['phone_number'];?></td>
    <td><?php echo $data['Email'];?></td>
    <td><?php echo $data['Role'];?></td>
    <td><?php echo $data['Days'];?></td>
    <td><img src="data:image;charset=utf8;base64,<?php echo base64_encode($data['image']); ?>" width="100px" height="100px"/> </td>
    <td><?php echo $data["created"]; ?></td>
</tr>
<?php 
$sn++;}}
else{?>
<tr> 
    <td colspan="8">No data found</td>
</tr>
<?php }?>
</table>