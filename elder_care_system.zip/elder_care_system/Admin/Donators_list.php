<?php
session_start();
include("../includes/config.php");
$query="select Name,Gender,Phone_Number,Email,Address,Amount,Project from donation";
$result=$con->query($query);
?>
<table border="1" cellspacing="0" cellpadding="10">
<tr>
<th>S.NO</th>
    <th>Name</th>
    <th>Gender</th>
    <td>Phone_Number</th>
    <th>Email</th>
    <th>Address</th>
    <th>Amount</th>
    <th>Project</th>
</tr>
<?php
if($result->num_rows>0)
{
    $sn=1;
    while($data=$result->fetch_assoc())
    {?> 
<tr>
    <td><?php echo $sn;?></td>
    <td><?php echo $data['Name'];?></td>
    <td><?php echo $data['Gender'];?></td>
    <td><?php echo $data['Phone_Number'];?></td>
    <td><?php echo $data['Email'];?></td> 
    <td><?php echo $data['Address'];?></td>
    <td><?php echo $data['Amount'];?></td>
    <td><?php echo $data['Project'];?></td> 
</tr>
<?php 
$sn++;}}
else{?>
<tr> 
    <td colspan="8">No data found</td>
</tr>
<?php }?>
</table>