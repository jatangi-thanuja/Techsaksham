<?php
// Include config file
require_once "../includes/config.php";
 
// Define variables and initialize with empty values
$email=$username = $password = $confirm_password = "";
$email_err=$username_err = $password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"])))
    {
       $username_err="please enter username";
    }
    else if(!empty(trim($_POST["username"])))
    {
        $username=trim($_POST["username"]);
    }
   if(empty(trim($_POST["email"]))){
        $email_err = "Please enter an email.";
    } elseif(!preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/', trim($_POST["email"]))){
        $email_err = "enter correct email address.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM userlogin WHERE Email = ?";
        
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["email"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $email_err = "This username is already taken.";
                } else{
                    $email = trim($_POST["email"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Check input errors before inserting in database
    if( empty($username_err) && empty($email_err) && empty($password_err) && empty($confirm_password_err)){
        
        $stmt = $con->prepare("insert into userlogin(username,Email,password)
        values(?,?,?)");
        $stmt->bind_param("sss",$username,$email,$password);
        $stmt->execute();
        echo "<script>
            alert('Your Account Created Successfully');
            location:'../Admin/loginform.php';
         </script>";
        $stmt->close();
    }
    
    // Close connection
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_signup.css">
<title> Elder Care Management System</title>
</head>
<body>
<div class="header">
  <p>Elder Care Management System</p>
</div>

<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../vacancyCheck/homelist.php">Vacancy Check</a>
  <a href="../ContactUs/contact.php">Contact us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>

<div class="content">
<?php
       if($email_err)
       {
        echo"<script>alert('$email_err')</script>";
       } 
       else if($password_err)
       {
          echo"<script>alert('$password_err')</script>";
       }
       else if($confirm_password_err)
       {
        echo"<script>alert('$confirm_password_err')</script>";
       }
      ?>
     <center>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
           <h1> Sign Up</h1>

      <input type="text" placeholder="Enter Usernaame" name="username" required></br>

  	 <input type="text" placeholder="Enter Email" name="email" required><br>
        
    	<input type="password" placeholder="Enter Password" name="password" required><br>

    	<input type="password" placeholder="Confirm Password" name="confirm_password" required><br>
    
   	 <label>
   	   <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
   	 </label><br>
    
    <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>
      <button type="submit" class="signupbtn">Sign Up</button>
    </div>
   <p>By signing up,you are agree to our <a href="../Homepage/conditions.php">Terms of use</a> and <a href="../HomePage/privacy.php">Privacy Policy.</a><p> 
   <p>Already have an account ? <a href="../Admin/loginform.php">Login</a><p>
  </div>
</form>
 </center>
 <div class="help">
 <button onclick="location.href='../Admin/loginform.php'"> Admin</button>
 </div>
 <div class="login">
    <button onclick="location.href='../Admin/loginform.php'">Login</button>
</div>
  
</div>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>

</body>
</html>

