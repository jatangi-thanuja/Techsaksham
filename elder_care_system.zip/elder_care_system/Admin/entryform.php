<?php
session_start();
include("../includes/config.php");
 $status=$statusmsg="";
 if(isset($_POST['submit']))
 {
    $status='error';
    $name=$_POST['name'];
     $gender=$_POST['gender'];
     $age=$_POST['age'];
     $phonenumber=$_POST['number'];
     $guardian=$_POST['guardian'];
     $guardiannumber=$_POST['phone'];
     $email=$_POST['email'];
     $address=$_POST['address'];
     $adminid=$_POST['adminid'];
    if(!empty($_FILES["image"]["name"]))
    {
        $filename=basename($_FILES["image"]["name"]);
        $filetype=pathinfo($filename,PATHINFO_EXTENSION);
        $allowTypes=array('jpg','png','jpeg','gif');
        if(in_array($filetype,$allowTypes))
        {
            $image=$_FILES['image']['tmp_name'];
            $imgcontent=addslashes(file_get_contents($image));
            $insert= $con->query("insert into citizens(name,gender,age,contact,guardian,guardiannumber,email,address,AdminId,image,created) values('$name','$gender','$age','$phonenumber','$guardian','$guardiannumber','$email','$address','$adminid','$imgcontent',NOW())");
            if($insert)
            {
                echo "<script type='text/javascript'>
            alert('file upload was  success ');
            location='../Admin/loginhome.php';
            </script>";
             }
            else
            {
                echo "<script type='text/javascript'>
                alert('fileupload falied ');
                location='../Admin/loginhome.php';
                </script>";
            }
        }
        else
        {
            echo "<script type='text/javascript'>
            alert('image should be in jpg,jpeg,png,gfg and it shoulb be less than 1 mb ');
            location='../Admin/loginhome.php';
            </script>";
        }
    }
    else
    {
        echo "<script type='text/javascript'>
            alert('please upload an image');
            location='../Admin/loginhome.php';
            </script>";
    }
 }
?>
<!DOCTYPE html>
<Html>  
<head>   
<title>  
Registration Page  
</title> 
<link rel="stylesheet" href="addform.css"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Elder Care Management System</title>
</head>  
<body>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post" enctype="multipart/form-data">
<div id="caption">
</div>      
<div class="left">
      <label> Name  </label><br>         
	<input type="text" name="name" size="15" required/> <br>    
	<label>   
	Gender   
	</label>  <br>
	<input type="radio" name="gender" value="Male" required/> Male   
	<input type="radio" name="gender" value="Female" required/> Female  
	<input type="radio" name="gender" value="Others" required/> Other  <br>  
	<label>Age </label><br>
	<input type="text" name="age" required/><br>
	<label>   
	Contact Number   
	</label><br>     
	<input type="text" name="number" size="10" required/><br> 
	<label>Guardian Name  </label> <br>
	<input type="text" name="guardian" required/><br>
        </div>
        <div class="right">
        <label>Guardian Number</label><br>
        <input type="text" name="phone" size="10" required/><br>
	Email  <br>
	<input type="email" id="email" name="email"/> <br>    
	Address 
	<br>  
	<textarea cols="40" rows="2" value="address" name="address">  
	</textarea>  <br>
    <label>AdminId</label><br>
    <input type="text" name="adminid"/><br>
    <label>Select Image File:</label>
    <input type="file" name="image"><br><br>
    <input type="submit" name="submit" value="Upload">
</div>
</form> 
</body>  
</html>