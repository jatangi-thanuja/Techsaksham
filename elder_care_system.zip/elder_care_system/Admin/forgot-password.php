<?php
session_start();
include("../includes/config.php");
if(isset($_POST["submit"]))
{
  $email=$_POST["email"];
  $username=$_POST["username"];
  $_SESSION["reset_username"]="$username";
  $_SESSION["reset_email"]="$email";
  $data="select * from userlogin where Email='$email' and username='$username'";
  $query=mysqli_query($con,$data);
  if(mysqli_num_rows($query)===1)
  {
    $otp=rand(1000,10000);
    $_SESSION["OTP"]="$otp";
    echo "<script type='text/javascript'>
    alert('$otp is otp  for password reset ');
    location='../Admin/reset-password.php';
    </script>";
  }
 else
  {
    echo "<script type='text/javascript'>
    alert('please enter valid credintials');
    location='../Admin/forgot-password.php';
    </script>";
 }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="forgot-password.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>
<title> Elder Care Management System</title>
</head>
<body>

<div class="header">
  <p>Elder Care Management System</p>
</div>
<div id="top">
         <button onclick="location.href='../Admin/loginform.php'">Admin</button>
</div>
<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../Admin/homelist.php">Vacancy Check</a>
  <a href="../ContactUs/contact.php">Contact Us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>

<div class="content">
  <center><h1>Enter your credintials and change the password</h1></center>
<form  method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
    <br><input type="username" name="username" placeholder="Username" required>
    <br><br><input id="email" name="email" placeholder="Email address"   type="email" required><br><br>
    <input name="submit" class="reset" value="Reset Password" type="submit">
</form>
</div>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>
</body>
</html>