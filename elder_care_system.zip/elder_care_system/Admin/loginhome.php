<?php
   session_start();
   if(!empty($_SESSION['id']) && !empty($_SESSION['username']))
   {
?>
<!DOCTYPE html>
  <html>
    <head>
         <title> Elder Care Management System</title>
         <link rel="stylesheet" href="loginhome.css">
         <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
 </head>
 <body>
     <div id="top"><center><h1> Welcome <?php echo $_SESSION["username"]?></h1></center></div>
     <div id="userSymbol" style='font-size:23px;position:absolute;top:75px;right:55px'><?php echo $_SESSION["username"];?>&nbsp&nbsp<i class='fas fa-user-circle'></i></div>
     <div class="symbol">
       <button onclick="location.href='index.php'">Home</button><br>
       <button id="add">Add Person</button><br>
       <button id="view">View Details</button><br>
       <button id="remove">Remove Person</button>
       <button id="donators" >Donation Details</button>
       <button id="volunteers" >Volunteer Details</button>
       <button id="contact">User Requests</button>
       <button id="logout" onclick="location.href='logout.php'">Logout</button>
    </div>
    <div id="loading">
   </div>
    <script>
        $(document).ready(function(){
           $("#add").click(function(){
                $("#loading").load("entryform.php");
           });
           $("#view").click(function(){
               $("#loading").load("citizendata.php");
           });
           $("#remove").click(function(){
              $("#loading").load("removeperson.php");
           });
           $("#donators").click(function(){
              $("#loading").load("Donators_list.php");
           });
           $("#volunteers").click(function(){
              $("#loading").load("../Volunteer/Volunteer_Data.php");
           });
           $("#contact").click(function(){
             $("#loading").load("user_list.php");
           });
        });
    </script>
</body>
</html>
<?php
  }
  else
  {
      header("Location:../Admin/loginform.php");
      exit();
  } 
?>