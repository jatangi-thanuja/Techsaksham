<?php
 session_start();
?>
<!DOCTYPE html>
<html>
    <head>
    <title> Elder Care Management System</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="removeperson.css">
    </head>
    <body>
        <center><p> Removing Citizen Data From Home </p></center>
        <div id="form">
        <form method="post" action="remove.php">
            <input type="text" name="id" value="enter adminid"/><br>
            <input type="submit" name="submit"/>
         </form>
       </div>
    </body>   
</html>