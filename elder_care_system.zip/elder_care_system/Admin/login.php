<?php
session_start();
include("../includes/config.php");
 if(isset($_POST['username']) && isset($_POST['password']))
 {
     function validate($data)
     {
        $data=trim($data);
        $dta=stripslashes($data);
        $data=htmlspecialchars($data);
        return $data;
     }
     $username=validate($_POST['username']);
     $password=validate($_POST['password']);

        $sql= "select * from  userlogin where Email='$username' and password='$password'";
        $result= mysqli_query($con,$sql);
        if(mysqli_num_rows($result)===1)
        {
            $row= mysqli_fetch_assoc($result);
            if($row['Email']===$username && $row['password']===$password)
            {
                $_SESSION['username']= $row['username'];
                $_SESSION['id']=$row['id'];
                header("Location:../Admin/loginhome.php");
            }
        }
        else
        {
            echo "<script type='text/javascript'>
            alert('Wrong Username or Password');
            location='../Admin/loginform.php';
            </script>";
        } 

    }
 else
{
  header("Location:../Admin/loginform..php");
  exit();
}
?>