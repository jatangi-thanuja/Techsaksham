<?php
 session_start();
 if(!empty($_SESSION["username"]))
 {
    header("Location:../Admin/loginhome.php");
 }
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="loginform.css">
<title> Elder Care Management System</title>
</head>
<body>

<div class="header">
  <p>Elder Care Management System</p>
</div>
<div id="top">
         <button onclick="location.href='../Admin/loginform.php'">Admin</button>
</div>

<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../vacancyCheck/homelist.php">Vacancy Check</a>
  <a href="../ContactUs/contact.php">Contact Us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us<a>
</div>

<div class="content">
<div class="section1">
      <h>LOGIN</h>
    <form action="../Admin/login.php" method="POST">
          <h id="error"> </h>
          <input type="text" name="username"  placeholder="Email Address" required/><br>     
         <input type="password" name="password"  placeholder="password" required/><br>
          <input type="submit"  value="Login"><br>
      <a href="../Admin/forgot-password.php">Forgot Password<a>
  </form>
   </div>
   <div class="section2">
    <center>
    <div class="para">
     <h1>Admin</h1>
     <p> Admin has to maintain all the data related<br>to old aged citizens in the given home.</p>
   </div>
   </center>
 </div>
 <div class="section3">
     <br><button type="submit" id="signup" onclick="location.href='../Admin/admin_signup.php'"> Sign Up </button>
 </div>
 </div>  
</div>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>

</body>
</html>





 