<?php
session_start();
include("../includes/config.php");
$query="select name,gender,age,contact,guardian,guardiannumber,email,address,AdminId,image from citizens";
$result=$con->query($query);
?>
<table border="1" cellspacing="0" cellpadding="10">
<tr>
    <th>S.NO</th>
    <th>Name</th>
    <th>Gender</th>
    <th>Age</th>
    <td>Contact Number</th>
    <th>Guardian Name</th>
    <th>Guardian Number</th>
    <th>Email</th>
    <th>Address</th>
    <th>AdminId</th>
    <th>Photo</th>
</tr>
<?php
if($result->num_rows>0)
{
    $sn=1;
    while($data=$result->fetch_assoc())
    {?> 
<tr>
    <td><?php echo $sn;?></td>
    <td><?php echo $data['name'];?></td>
    <td><?php echo $data['gender'];?></td>
    <td><?php echo $data['age'];?></td>
    <td><?php echo $data['contact'];?></td>
    <td><?php echo $data['guardian'];?></td>
    <td><?php echo $data['guardiannumber'];?></td>
    <td><?php echo $data['email'];?></td> 
    <td><?php echo $data['address'];?></td>
    <td><?php echo $data['AdminId'];?></td>
    <td><img src="data:image;charset=utf8;base64,<?php echo base64_encode($data['image']); ?>" width="100px" height="100px"/> </td>
</tr>
<?php 
$sn++;}}
else{?>
<tr> 
    <td colspan="8">No data found</td>
</tr>
<?php }?>
</table>