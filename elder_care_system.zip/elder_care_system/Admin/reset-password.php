<?php
require_once("forgot-password.php");
if(isset($_POST["submit_form"]))
{
  $entered_otp=$_POST["otp"];
  $new_password=$_POST["new-password"];
  $confirm_password=$_POST["confirm-password"];
  if($_SESSION["OTP"]!=$entered_otp)
  {
    echo "<script type='text/javascript'>
    alert('please enter correct OTP');
    location='reset-password.php';
    </script>";
  }
  else if(strlen(trim($_POST["new-password"])) < 6)
  {
    echo "<script type='text/javascript'>
    alert('Password must have atleast 6 characters.');
    location='reset-password.php';
    </script>";
  }
  else if($new_password!=$confirm_password)
  {
    echo "<script type='text/javascript'>
    alert('passwords did not match');
    location='reset-password.php';
    </script>";
  }
  else
  {
    $entered_username=$_SESSION["reset_username"];
    $entered_email=$_SESSION["reset_email"];
    $query= "update userlogin set password='$new_password' where Email='$entered_email' and username='$entered_username'";
     $result= mysqli_query($con,$query);
     if($result)
     {
      echo "<script type='text/javascript'>
      alert('Your password changed successfully');
      location='loginform.php';
      </script>";
     }
     else
     {
      echo "<script type='text/javascript'>
      alert('somethingwent wrong');
      location='forgot-password.php';
      </script>";
     }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
<title> Elder Care Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="reset-password.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>
</head>
<body>
<div class="content">
<form  method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
    <br><input type="otp" name="otp" placeholder="Enter OTP" required>
    <br><br><input  name="new-password" placeholder="Enter New password"   type="password" required><br>
    <br><input  name="confirm-password" placeholder="confirm password"   type="password" required><br><br>
    <input name="submit_form" class="reset" value="Reset Password" type="submit"><br><br>
    <button onclick="location.href='forgot-password.php'" style="border-radius:15px;">Resend</button>
</form>
</div>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>
</body>
</html>