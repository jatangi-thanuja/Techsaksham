<?php
   include("../includes/config.php");
   if(isset($_POST["submit"]))
   {
        $adminid=$_POST["id"];
        $query="select * from citizens where AdminId='$adminid'";
        $result=mysqli_query($con,$query);
        $rows=mysqli_num_rows($result);
        if($rows==0)
        {
            echo "<script type='text/javascript'>
            alert('Data not found');
            location='loginhome.php';
            </script>";
        }
       else
        {
        $del=mysqli_query($con,"delete from citizens where AdminId='$adminid'");
        if($del)
        {
            echo "<script type='text/javascript'>
            alert('Citizen data deleted successfully.');
            location='loginhome.php';
            </script>";
       }
       else
       {
        echo "<script type='text/javascript'>
        alert('Error in removing the data');
        location='loginhome.php';
        </script>";
       }
    }
    }
?>