<?php
     session_start();
     include("../includes/config.php"); 
	  if(isset($_POST['submit']))
	   {
            $name=$_POST["name"];
			$phone_number=$_POST["Phone"];
			$email=$_POST["mail"];
			$address=$_POST["address"];
			$message=$_POST["message"];
			if(!preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/', trim($_POST["mail"])))
			{
			
				echo "<script type='text/javascript'>
				alert('Please enter correct email address');
				location='contact.php';
				</script>";
            }
		    $query="insert into contact(Name,Phone_Number,Email,Address,Message) values('$name','$phone_number','$email','$address','$message')";
			$result= mysqli_query($con,$query);
			if($result)
			{
				echo "<script type='text/javascript'>
            alert('Your data recorded successfully');
            location='contact.php';
            </script>";
			}
		else
		   {
			echo "<script type='text/javascript'>
            alert('Something went wrong!please try again.');
            location='contact.php';
            </script>";
			}
		}
	
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="contact.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title> Elder Care Management System</title>	
</head>
<body>

<div class="header">
  <p>Elder Care Management System</p>
</div>
<div id="top">
         <button onclick="location.href='loginform.php'">Admin</button>
</div>
<div id="navbar">
  <a class="active" href="../HomePage/index.php">Home</a>
  <a href="../vacancyCheck/homelist.php">Vacancy check</a>
  <a href="../ContactUs/contact.php">Contact us</a>
  <a href="../Volunteer/volunteer.php">Volunteer</a>
  <a href="../Donation/donation.php">Donation</a>
  <a href="../Media/media.php">Media</a>
  <a href="../AboutUs/aboutus.php" style="float:right">About Us</a>
</div>

<div class="content">
<script>
	function fun(){
	document.getElementById("button").style.background="green";
	}
	function out(){
		document.getElementById("button").style.background="white";
	}
</script>
<div style="text-align:center">
			<h2 style="color:white">CONTACT US</h2>
</div>
<div class="data">
		<table>
    	<tr>
				<td>
					<i class="fa fa-map-marker" style="font-size:50px"></i>
				</td>
				<td>
					<p><i>LOCATION</P>
					<iframe style="border-radius:35px"src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15462.349815297242!2d78.5398846!3d14.3353797!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x88cc62e6279e1ef0!2sIIIT%20RGUKT%20RK%20VALLEY!5e0!3m2!1sen!2sin!4v1674463516498!5m2!1sen!2sin" width="400" height="150" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe><br><br>
				</td>
		</tr>
		<tr>
			<td>
				<i class="fa fa-phone" style="font-size:50px"></i>
			</td>
		<td>
			<p><b>CALL US ON</b></p>
			<p>011-055-000</p>
		</td>
	</tr>
	<tr>
			<td><i class="fa fa-envelope" style="font-size:36px"></i></td>
			<td>
			<p><b>SEND YOUR MESSAGE</b></p>
			<p>r170045@rguktrkv.ac.in</p></td>
	</tr>
</table>
</div>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>" method="post">
<i>
	<div class="b">
		<label for="name">Name:</label><br>
		<input type="text" name="name"placeholder="enter name" required><br><br>
		<label for="phone">Phone:</label><br>
		<input type="text" name="Phone" placeholder="phone number" required><br><br>
		<label for="mail">Mail:</label><br>
		<input type="text" name="mail" required><br><br>
		<label for="Address">Address:</label><br>
		<textarea id="Address" name="address" required></textarea><br><br>
		<label for="message">Message:</label><br>
		<textarea id="message" name="message" required></textarea><br><br>
		<input type="submit"  name="submit" onmouseover="fun()" onmouseout="out()"id="button"value="submit">
	</div>
</form>
</div>

<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>

</body>
</html>
